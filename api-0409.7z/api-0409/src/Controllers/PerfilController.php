<?php

namespace App\Controllers;

use PDO;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Monolog\Logger;
use App\Helpers\ResponseHelper;

class PerfilController
{
    private $db;
    private $logger;

    public function __construct(PDO $db, Logger $logger)
    {
        $this->db = $db;
        $this->logger = $logger;
    }

    public function obtenerPerfil(Request $request, Response $response): Response
    {
        $user = $request->getAttribute('usuario'); // Asumiendo que el JwtMiddleware añade este atributo
        $responseHelper = new ResponseHelper($response);

        $sql = "SELECT 
                    nombre, 
                    apellidos, 
                    nacionalidad, 
                    fechanac, 
                    sexo,
                    persons_estado_civil_type.name  as estado_civil,
                    canthijos,
                    domicilio,
                    barrio,
                    city_id,
                    distrito_id,
                    tel, 
                    email,
                    tel_celular,
                    tel_celular_2,
                    otro_celular_1,
                    otro_celular_2
                FROM personas.persons  
                LEFT JOIN personas.persons_estado_civil_type ON persons_estado_civil_type.id = persons.estado_civil
                WHERE persons.id = :id";

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id' => $user->userIdPerson]);
            $perfil = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$perfil) {
                $this->logger->info("Perfil no encontrado para el usuario ID: $user->userId");
                return $responseHelper->respondWithError('Perfil no encontrado', 404);
            }

            $this->logger->info("Perfil obtenido exitosamente para el usuario ID: $user->userId");
            return $responseHelper->respondWithJson($perfil, 200, 'Perfil obtenido exitosamente');
        } catch (\PDOException $e) {
            $this->logger->error("Error al obtener el perfil: " . $e->getMessage());
            return $responseHelper->respondWithError('Error al obtener el perfil', 500);
        }
    }

    public function actualizarPerfil(Request $request, Response $response): Response
    {
        $userId = $request->getAttribute('userId');
        $data = $request->getParsedBody();
        $responseHelper = new ResponseHelper($response);

        $updateFields = [
            'nombre', 'apellidos', 'nacionalidad', 'fechanac', 'sexo', 'estado_civil',
            'canthijos', 'domicilio', 'city_id', 'distrito_id', 'esindigena', 'actualizado',
            'tel', 'email', 'tel_celular', 'barrio', 'trabaja', 'hogar_jefatura',
            'trabaja_especificar', 'discapacidad', 'tel_celular_pertenece',
            'tel_celular_2', 'tel_celular_pertenece_2', 'razon_no_trabaja',
            'otro_celular_1', 'otro_celular_2', 'no_trabaja_otro', 'tipo_discapacidad',
            'hogar_jefatura_otro'
        ];

        $updateData = array_intersect_key($data, array_flip($updateFields));

        if (empty($updateData)) {
            return $responseHelper->respondWithError('No se proporcionaron datos para actualizar', 400);
        }

        $sql = "UPDATE personas.persons SET " . 
               implode(', ', array_map(fn($field) => "$field = :$field", array_keys($updateData))) . 
               " WHERE id = :id";

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(array_merge($updateData, ['id' => $userId]));

            if ($stmt->rowCount() === 0) {
                $this->logger->info("No se realizaron cambios en el perfil del usuario ID: $userId");
                return $responseHelper->respondWithJson(null, 200, 'No se realizaron cambios');
            }

            $this->logger->info("Perfil actualizado exitosamente para el usuario ID: $userId");
            return $responseHelper->respondWithJson(null, 200, 'Perfil actualizado exitosamente');
        } catch (\PDOException $e) {
            $this->logger->error("Error al actualizar el perfil: " . $e->getMessage());
            return $responseHelper->respondWithError('Error al actualizar el perfil', 500);
        }
    }

    public function obtenerCursosInscritos(Request $request, Response $response): Response
    {
        $user = $request->getAttribute('usuario');
        $responseHelper = new ResponseHelper($response);

        $sql = "SELECT 
                    ve.id_especialidades,
                    ve.especialidad,
                    ve.area,
                    ve.familia,
                    ve.carga_horaria,
                    ia.fecha_inscripcion,
                    ei.descripcion as estado_inscripcion,
                    ia.observacion,
                    ia.aprobado
                FROM inscripcion_alumnos.alumno al
                JOIN inscripcion_alumnos.inscripcion_alumno ia ON ia.id_alumno = al.id_alumno
                JOIN planificacion.planificacion pl ON ia.id_planificacion = pl.id_planificacion
                JOIN planificacion.vista_especialidad ve ON ve.id_especialidades = pl.id_especialiadad
                JOIN inscripcion_alumnos.estado_inscripcion ei ON ei.id = ia.estado_inscripcion
                WHERE al.id_usuario = :id_alumno AND ei.descripcion = 'ACTIVO'";

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_alumno' => $user->userId]);
            $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $this->logger->info("Cursos inscritos obtenidos exitosamente para el usuario ID: $user->userId");
            return $responseHelper->respondWithJson($cursos, 200, 'Cursos obtenidos exitosamente');
        } catch (\PDOException $e) {
            $this->logger->error("Error al obtener los cursos inscritos: " . $e->getMessage());
            return $responseHelper->respondWithError('Error al obtener los cursos inscritos', 500);
        }
    }

    public function inscribirEnCurso(Request $request, Response $response): Response
    {
        // $userId = $request->getAttribute('userId');
        // $data = $request->getParsedBody();
        // $idPlanificacion = $data['id_planificacion'] ?? null;
        $responseHelper = new ResponseHelper($response);

        // if (!$idPlanificacion) {
        //     return $this->respondWithJson($response, ['error' => 'ID de planificación no proporcionado'], 400);
        // }

        // // Verificar si el curso existe y está disponible
        // $sqlVerificar = "SELECT 1 FROM planificacion.cursos_disponibles 
        //                  WHERE id_planificacion = :id_planificacion 
        //                  UNION 
        //                  SELECT 1 FROM planificacion.cursos_disponibles_emprendedurismo 
        //                  WHERE id_planificacion = :id_planificacion
        //                  UNION 
        //                  SELECT 1 FROM planificacion.cursos_disponibles_generacion_digital 
        //                  WHERE id_planificacion = :id_planificacion";

        // try {
        //     $stmtVerificar = $this->db->prepare($sqlVerificar);
        //     $stmtVerificar->execute(['id_planificacion' => $idPlanificacion]);
        //     if ($stmtVerificar->fetchColumn() === false) {
        //         return $this->respondWithJson($response, ['error' => 'Curso no disponible'], 404);
        //     }

        //     // Insertar la inscripción
        //     $sqlInscribir = "INSERT INTO inscripcion_alumnos.inscripcion_alumno 
        //                      (id_alumno, id_planificacion) VALUES (:id_alumno, :id_planificacion)";
        //     $stmtInscribir = $this->db->prepare($sqlInscribir);
        //     $stmtInscribir->execute([
        //         'id_alumno' => $userId,
        //         'id_planificacion' => $idPlanificacion
        //     ]);

        //     $this->logger->info("Usuario ID: $userId inscrito exitosamente en el curso ID: $idPlanificacion");
        //     return $this->respondWithJson($response, ['message' => 'Inscripción exitosa']);
        // } catch (\PDOException $e) {
        //     $this->logger->error("Error al inscribir en el curso: " . $e->getMessage());
        //     return $this->respondWithJson($response, ['error' => 'Error al inscribir en el curso'], 500);
        // }
        return $responseHelper->respondWithError('Error al inscribir a curso', 500);
    }

    
}